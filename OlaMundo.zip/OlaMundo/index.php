<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        echo "<h1>Primeiro Programa em PHP</h1>";
        echo "<br>";
        echo "Olá Mundo!";
        $nome = "Mateus";
        echo "<br>";
        echo "Bom dia $nome";
        
        ?>
    </body>
</html>
